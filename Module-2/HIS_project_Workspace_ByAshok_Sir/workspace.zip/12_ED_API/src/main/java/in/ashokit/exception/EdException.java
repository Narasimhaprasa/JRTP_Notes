package in.ashokit.exception;

public class EdException extends RuntimeException {

	public EdException() {
		// TODO Auto-generated constructor stub
	}

	public EdException(String msg) {
		super(msg);
	}

}