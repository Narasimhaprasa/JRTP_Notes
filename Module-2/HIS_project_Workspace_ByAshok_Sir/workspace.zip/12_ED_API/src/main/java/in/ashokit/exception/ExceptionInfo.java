package in.ashokit.exception;

import lombok.Data;

@Data
public class ExceptionInfo {
	
	private String code;
	private String msg;

}
