package in.ashokit.service;

import in.ashokit.binding.CoResponse;

public interface CoService {

	public CoResponse processPendingTriggers();

}
