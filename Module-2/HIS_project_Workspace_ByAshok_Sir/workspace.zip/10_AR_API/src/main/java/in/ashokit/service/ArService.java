package in.ashokit.service;

import in.ashokit.binding.CitizenApp;

public interface ArService {

	public Integer createApplication(CitizenApp app);

}
