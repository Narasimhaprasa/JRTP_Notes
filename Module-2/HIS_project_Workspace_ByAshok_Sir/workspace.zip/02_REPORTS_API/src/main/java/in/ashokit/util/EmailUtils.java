package in.ashokit.util;

import java.io.File;

import org.springframework.stereotype.Component;

@Component
public class EmailUtils {

	private JavaMailSender mailSender;

	public boolean sendEmail(String subject, String body, String to, File file) {
		
		try {
			
		}catch(Exception e) {
			
		}
		
	}

}
