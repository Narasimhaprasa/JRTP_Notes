package in.ashokit.bindings;

import lombok.Data;

@Data
public class Login {

	private String email;

	private String password;

}