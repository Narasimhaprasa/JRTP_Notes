package in.ashokit.binding;

import lombok.Data;

@Data
public class Child {

	private String childName;
	private Integer childAge;
	private Long childSsn;

}
