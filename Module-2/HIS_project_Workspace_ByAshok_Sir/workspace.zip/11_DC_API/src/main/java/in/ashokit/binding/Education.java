package in.ashokit.binding;

import lombok.Data;

public class Education {

	private Long caseNum;
	private String highestQualification;
	private Integer graduationYear;
	private String universityName;

}
